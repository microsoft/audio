1. Double click CollectAudioLogs.cmd
2. If you can reproduce your problem, do so with while tracing by answering 'y' to the first question. Otherwise answer 'n'.
2a. If you answered 'y', hit enter when you are finished reproducing the problem to stop tracing.
3. If system logs would be helpful answer 'y' to the second question, othwerise answer 'n'. If in doubt, answer 'y'.
4. A zip file with the name COMPUTERNAME_<timestamp> containing all the logs will be created in the script directory when finished.